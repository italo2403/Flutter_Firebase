import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Favorite Car',
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Votos de carros Favoritos'),
      ),
      body: CarList(),
    );
  }
}

class CarList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('cars').snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return CircularProgressIndicator();
        return ListView.builder(
          itemCount: snapshot.data!.docs.length,
          itemBuilder: (context, index) {
            final DocumentSnapshot document = snapshot.data!.docs[index];
            final data = document.data() as Map<String, dynamic>;
            final String carName = data['name'];
            final int votes = data['votes'] ?? 0;

            return ListTile(
              title: Text(carName),
              subtitle: Text('Votes: $votes'),
              onTap: () => _editVotes(context, document.reference, votes),
            );
          },
        );
      },
    );
  }

  void _editVotes(BuildContext context, DocumentReference reference,
      int currentVotes) async {
    int? newVotes = await showDialog<int>(
      context: context,
      builder: (context) => EditVotesDialog(currentVotes: currentVotes),
    );

    if (newVotes != null) {
      await reference.update({'votes': newVotes});
    }
  }
}

class EditVotesDialog extends StatefulWidget {
  final int currentVotes;

  EditVotesDialog({required this.currentVotes});

  @override
  _EditVotesDialogState createState() => _EditVotesDialogState();
}

class _EditVotesDialogState extends State<EditVotesDialog> {
  late TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.currentVotes.toString());
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Edit Votes'),
      content: TextField(
        controller: _controller,
        keyboardType: TextInputType.number,
        decoration: InputDecoration(labelText: 'New Votes'),
      ),
      actions: <Widget>[
        TextButton(
          child: Text('Cancel'),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        TextButton(
          child: Text('Save'),
          onPressed: () {
            int newVotes =
                int.tryParse(_controller.text) ?? widget.currentVotes;
            Navigator.of(context).pop(newVotes);
          },
        ),
      ],
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}
