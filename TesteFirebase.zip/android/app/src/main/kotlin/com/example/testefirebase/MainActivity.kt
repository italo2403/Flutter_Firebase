package com.example.testefirebase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
